Packaging quick reminder
========================

Make sure maintainer dependencies are installed::

    pip install -e .[maintainer,dev]

Run release command and follow prompt instructions::

    fullrelease
